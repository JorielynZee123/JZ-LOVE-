# fbw
Facebook Cloning Script Written in Python ...Enjoy !!!



To Install Use These Commands:

1-One Line Command


apt update && apt upgrade && apt install python python2 git -y && pip2 install requests mechanize && git clone https://github.com/faizanwahla/fbw && cd fbw && python2 fbw.py

2-Multiple Line Command


apt update                                                                                                   
apt upgrade                                                                                              
apt install python                                                                                   
apt install python2                                                                                           
apt install git -y                                                                               
pip2 install requests mechanize                                                                                
git clone https://github.com/faizanwahla/fbw
cd fbw                                                                                                                           
python2 fbw.py                                                                                                                   





